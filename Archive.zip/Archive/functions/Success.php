<?php
	function Added($conn){
		echo "<center>Account Successfully Added</center>";
	}

	function uploaded($conn){
		echo "<center> Uploaded Successfully </center>";
	}

	function deleted($conn){
		echo "<center> Deleted Successfully </center>";
	}
?>