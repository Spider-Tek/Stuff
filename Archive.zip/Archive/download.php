<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<form method="POST">
    <input type="text" name="pdf"/>
    <button name="btn"> Open </button>
</form>
</body>
</html>

<?php
    if (isset($_POST['btn'])) {
        $pdf1 = $_POST['pdf'];

        $pdf = 'pdf/'.$pdf1.'.pdf'; 
        header('Content-type: application/pdf');
        header('Content-Disposition: inline; filename="'.$pdf.'"'); 
        readfile($pdf);
    }
    

?>