<?php
	include_once"includes/conn.php";
	$id = $_SESSION['id'];

	$sql = "SELECT * FROM users WHERE Username = '$id' ";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result)>0) {
		while ($rows = mysqli_fetch_assoc($result)) {
			$uname = $rows['Username'];
			$dpt = $rows['Department'];
			$status = $rows['Status'];
			$fullname = $rows['Fullname'];
		}
	}

	
?>


