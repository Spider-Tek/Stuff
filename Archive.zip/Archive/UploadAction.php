<?php
	session_start();
	include_once"includes/conn.php";
	include_once"functions/ErrorUpload.php";
	$id = $_SESSION['id'];

	if (isset($_POST['upload'])) {
		$file = $_FILES['file'];
		$dpt = $_POST['dpt'];
		$DocName = $_POST['docname'];
		$date = $_POST['date'];

	
		$filename = $_FILES['file']['name'];
		$filesize = $_FILES['file']['size'];
		$fileTmpName = $_FILES['file']['tmp_name'];
		$fileError = $_FILES['file']['error'];
		$fileType = $_FILES['file']['type'];

		$sqlC = "SELECT Filename FROM document WHERE Department = '$dpt' ";
		$resC = mysqli_query($conn,$sqlC);
		if (mysqli_num_rows($resC)>0) {
			while ($rows = mysqli_fetch_assoc($resC)) {
				$checkname = $rows['Filename'];
			}
			if ($checkname == $DocName) {
				$_SESSION['er'] = 'NameExist';
				NameExist($conn);
				header('Location: upload.php');
				exit();
			}
		}

		if ($dpt == 'None') {
			$_SESSION['er'] = 'Nonedpt';
			Nonedpt($conn);
			header('Location: upload.php');
		}elseif (empty($DocName)) {
			$_SESSION['er'] = 'fn';
			FileName($conn);
			header('Location: upload.php');
		}else{
			$fileExt = explode('.', $filename);
		$fileActExt = strtolower(end($fileExt));

		$allowed = array('pdf');
		$typepos = explode('/', $fileType);
		$fileType = strtolower(end($typepos));

		if (in_array($fileActExt, $allowed)) {
			if ($fileError === 0) {
				if ($filesize < 5000000) {
					$fileNewName = $DocName.'.'.$fileActExt;
					$fileDestination = 'Document/'.$fileNewName;
					move_uploaded_file($fileTmpName, $fileDestination);
					$filesize = $filesize / 1024;
					$filesize = substr($filesize, 0, 3);

					$sql = "INSERT INTO document (Department, FileName, Type, Size, Date_uploaded) VALUES('$dpt', '$DocName', '$fileType', '$filesize".'kb'."', '$date') ";
					$result = mysqli_query($conn,$sql);
					$_SESSION['suc'] = 'uploaded';
					header('Location: upload.php');
				}else{
					$_SESSION['er'] = 'File2Large';
					header('Location: upload.php');
				}
			}else{
					$_SESSION['er'] = 'ErrorUp';
					header('Location: upload.php');
				
			}
		}else{
					$_SESSION['er'] = 'Extension';
					header('Location: upload.php');
			}

		}
		

		

	}

?>