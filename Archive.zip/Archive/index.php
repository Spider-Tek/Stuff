<?php
	
	session_start();
	include_once"includes/conn.php";
	include_once"functions/Error.php";
	if (isset($_SESSION['id'])) {
		header('Location: upload.php');
	}
	echo $_SESSION['er'];
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="device-width initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.6.3/css/font-awesome.css">
</head>
<body style="background:#F3F3F3">
		<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Archive</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 1px;">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="#">Home</a></li>
          </ul>
        </div><!--/.nav-collapse -->
     
    </nav>	

    	<div class="fm">
    	<div class="alert alert-danger <?php
    		if (isset($_SESSION['er'])) {
    			echo "sr-only1";
    		}else{
    			echo "sr-only";
    		}
    	?>" role="alert" >
        <center><strong> <?php

        if (isset($_SESSION['er']) && $_SESSION['er'] !== NULL) {
        	if ($_SESSION['er'] == 'emp') {
        		EmptyField($conn);
        		$_SESSION['er'] = NULL;
        	}elseif ($_SESSION['er'] == 'inv') {
        		invalidAcc($conn);
        		$_SESSION['er'] = NULL;
        	}
        }
        ?> </strong></center>
      </div>
        <div class="form_con">
            <div class="cir">
            <!-- <img src=""> -->
            </div> 
            	<form method="POST" action="LoginAction.php">
            		<h3> Please Sign in </h3>
            		<div class="con"><input type="text" name="uname" class="form-control" placeholder="Username" /></div>
            		
            		<div class="con"><input type="password" name="pword" class="form-control" placeholder="Password" /></div>
            		 <button class="btn btn-md btn-primary btn-block" type="submit" name="Login">Sign in</button>
            	</form>
               
        </div>
    	</div><br>
    	<center class="<?php 
    		if (isset($_POST['Login'])) {
    			echo "sr-only1";
    		}else{
    			echo "sr-only";
    		}
    	?>"><i class="fa fa-spinner fa-3x fa-spin"></i></center>
	   <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
     <footer class="footer">
      <div class="container">
        <p class="text-muted">A Project By Eng. Eniola Olusanjo from the Department of Electrical Electronics</p>
      </div>
    </footer>

     </div>

		
  <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.1.1.js"></script>
    <!-- <script>window.jQuery || document.write('<script src="js/vendor/jquery.min.js"><\/script>')</script> -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
	
</body>
</html>