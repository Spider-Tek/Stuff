<?php
	session_start();
	include_once"includes/conn.php";

	if (isset($_POST['view'])) {
		$filename = $_POST['Docname'];

		$pdf = 'document/'.$filename.'.pdf'; 
        header('Content-type: application/pdf');
        header('Content-Disposition: inline; filename="'.$pdf.'"'); 
        readfile($pdf); 
	}
		
    if (isset($_POST['Delete'])) {
          $dpt = $_POST['dpt'];
          $Docname = $_POST['Docname'];

          $filedel = 'Document/'.$Docname."*";
          $filedel_ = glob($filedel);
          $filedelExt = explode('.', $filedel_[0]);
          $filedelActExt = $filedelExt[1];

          $file2del = "Document/".$Docname.".".$filedelActExt;

          unlink($file2del);
         
            $sql = "DELETE FROM document WHERE Department = '$dpt' AND Filename = '$Docname' ";
            $res = mysqli_query($conn,$sql);
            if ($res) {
              $_SESSION['suc'] = 'deleted';

              header('Location: Admin.php');
            }
          
          
        }

?>