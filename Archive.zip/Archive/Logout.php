<?php
	session_start();
	include_once"includes/conn.php";

	session_destroy();
	header('Location: index.php');
?>