<?php
	session_start();
	include_once"includes/conn.php";
	include_once"functions/Error.php";

	if (isset($_POST['Login'])) {
		$username = mysqli_real_escape_string($conn,strip_tags($_POST['uname']));
		$password = mysqli_real_escape_string($conn,strip_tags($_POST['pword']));

		if (empty($username) || empty($password)) {
			$_SESSION['er'] = 'emp';
			EmptyField($conn);
			header('Location: index.php');
		}else{
			$sql = "SELECT * FROM users WHERE Username = '$username' AND Password = '$password' ";
		$result = mysqli_query($conn,$sql);
		if (mysqli_num_rows($result)>0) {
			while ($rows = mysqli_fetch_assoc($result)) {
				$uname = $rows['Username'];
				$dpt = $rows['Department'];
				$sqlS = "SELECT Status FROM users WHERE Username = '$uname' ";
				$resS = mysqli_query($conn,$sqlS);
				if (mysqli_num_rows($resS)>0) {
					while ($rowS = mysqli_fetch_assoc($resS)) {
						$status = $rowS['Status'];
						if ($status == 'Staff') {
							$_SESSION['id'] = $uname;
							header('Location: upload.php');
						}else{
							$_SESSION['id'] = $uname;
							$_SESSION['dpt'] = $dpt;
							header('Location: Admin.php');
						}	
					}
				}
			}

			
		}else{
			$_SESSION['er'] = 'inv';
			invalidAcc($conn);
			header('Location: index.php');
		}
	}
		
	}

?>