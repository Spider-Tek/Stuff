<?php
              if (isset($_POST['search'])) {
  
                                      $dpt = $_POST['dpt'];
                                      $Docname = $_POST['Docname'];

                                      $sql = "SELECT * FROM document WHERE Department = '$dpt' OR Filename = '$Docname' ";
                                                  $res = mysqli_query($conn,$sql);
                                                    if (mysqli_num_rows($res)>0) {
                                                        while ($rows = mysqli_fetch_assoc($res)) {
                                                          $Docname = $rows['Filename'];
                                                          $dpt = $rows['Department'];
                                                          $type = $rows['Type'];
                                                          $size = $rows['Size'];
                                                          $date = $rows['Date_uploaded'];

                               echo"
                                  
                                  <form method='POST' action='AdminAction.php'>      
                                  <tr class='gradeX'>
                                  <td> $Docname </td>
                                  <td>$dpt</td>
                                  <td>$type</td>
                                  <td class='center'>$size</td>
                                  <td class='center'>$date</td>
                                  <td class='center'>
                                  <input type='hidden' name='Docname' value='$Docname' />
                                  <input type='hidden' name='dpt' value='$dpt' />
                                  <div class='upbtn'> <button name='view' class='btn btn-sm btn-default btn-block'> View </button></div>
                                   </td>
                                    <td class='center'>
                                  <div class='upbtn'> <button name='Delete' class='btn btn-sm btn-default btn-block'> Delete </button></div>
                                   </td>
                                   </tr>
                                  </form>
                              ";
                         }
                                                    
                    }
                      }elseif (isset($_POST['viewAll'])) {
                         $sql = "SELECT * FROM document ";
                                                  $res = mysqli_query($conn,$sql);
                                                    if (mysqli_num_rows($res)>0) {
                                                        while ($rows = mysqli_fetch_assoc($res)) {
                                                          $Docname = $rows['Filename'];
                                                          $dpt = $rows['Department'];
                                                          $type = $rows['Type'];
                                                          $size = $rows['Size'];
                                                          $date = $rows['Date_uploaded'];

                               echo"
                                  <form method='POST' action='AdminAction.php'>      
                                  <tr class='gradeX'>
                                  <td> $Docname </td>
                                  <td>$dpt</td>
                                  <td>$type</td>
                                  <td class='center'>$size</td>
                                  <td class='center'>$date</td>
                                  <td class='center'>
                                  <input type='hidden' name='Docname' value='$Docname' />
                                  <input type='hidden' name='dpt' value='$dpt' />
                                  <div class='upbtn'> <button name='view' class='btn btn-sm btn-default btn-block'> View </button></div>
                                   </td>
                                   <td class='center'>
                                  <div class='upbtn'> <button name='Delete' class='btn btn-sm btn-default btn-block'> Delete </button></div>
                                   </td>
                                   </tr>
                                  </form>
                              ";
                         }
                                                    
                    }
                      }

                      
?>