<?php
  session_start();
  include_once"includes/conn.php";
  include_once"functions/ErrorUpload.php";
  include_once"functions/Success.php";
  include_once"includes/UserDetails.php";
  date_default_timezone_set('Africa/Lagos');
  if (!isset($_SESSION['id'])) {
    header('Location: index.php');
  }
  $id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="device-width initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="font-awesome-4.6.3/css/font-awesome.css">
</head>
<body style="background:#F3F3F3">
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Archive</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 1px;">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href=""> <div class="User">Welcome <?php echo $id ?> </div> </a></li>
             <li><a href="Logout.php">Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
     
    </nav>  <br><br><br>
     <div class="row">
                    <div class="col-md-6" style="margin-left:2%">
                     <h2>DropBox Panel  </h2>    
                     <h4> Department <i class="fa fa-arrow-right"></i>  <?php echo $dpt; ?> <i class="fa fa-arrow-right"></i> Status:  <?php echo $status; ?>  </h4>
                    </div><br><br>
                    <div class="col-md-4">
                        <h4> Name: <?php echo $fullname; ?> </h4> 
                    </div>
      </div><hr />
      <div class="fm1">
        <div class="alert alert-danger <?php
          if (isset($_SESSION['er'])) {
            echo "sr-only1";
          }else{
            echo "sr-only";
          }
         ?>" role="alert">
        <strong><?php
        if (isset($_SESSION['er']) && $_SESSION['er'] !== NULL) {
          if ($_SESSION['er'] == 'fn') {
            FileName($conn);
            $_SESSION['er'] = NULL;
          }elseif ($_SESSION['er'] == 'Nonedpt') {
            Nonedpt($conn);
            $_SESSION['er'] = NULL;
          }elseif ($_SESSION['er'] == 'File2Large') {
            File2Large($conn);
            $_SESSION['er'] = NULL;
          }elseif ($_SESSION['er'] == 'ErrorUp') {
            ErrorUp($conn);
            $_SESSION['er'] = NULL;
          }elseif ($_SESSION['er'] == 'Extension') {
            Extension($conn);
            $_SESSION['er'] = NULL;
          }elseif ($_SESSION['er'] == 'NameExist') {
            NameExist($conn);
            $_SESSION['er'] = NULL;
          }
        }
        ?></strong>
      </div>
     
       <div class="panel panel-default">
       <div class="panel panel-heading">
         <h4> Upload Document </h4>
         
       </div>

        <form method="POST" enctype="multipart/form-data" action="UploadAction.php">
        <div class="con"><select class="form-control" name="dpt" value="">
                <option name="" value="None">-------------------- Select department --------------------</option>
                <!-- <option name="" value="Computer Science">COMPUTER SCIENCE</option> -->
                <option name="" value="Electrical Electronics">ELECTRICAL ELECTRONICS</option>
                <!-- <option name="" value="Mathematics">MATHEMATICS</option> -->
              </select>
        </div>
        <div class="con"><input type="text" name="docname" class="form-control" placeholder="File Name" /></div>
        <input type="hidden" name="date" value="<?php echo date('Y-m-d'); ?>">
        <div class="con"><input type="file" name="file" class="form-control" placeholder="Password" /></div>
         <div class="con"><button class="btn btn-md btn-primary" name="upload" type="submit">Upload</button></div>

      </form>
      <br><br><br>
     </div>
      <div class="alert alert-success <?php
        if (isset($_SESSION['suc'])) {
            echo "sr-only1";
          }else{
            echo "sr-only";
          }
         ?>
       ?>" role="alert">
        <strong><?php
        if (isset($_SESSION['suc']) && $_SESSION['suc'] !== NULL) {
          if ($_SESSION['suc'] == 'uploaded') {
            Uploaded($conn);
            $_SESSION['suc'] = NULL;
          }
        }
        ?></strong> 
      </div>
      </div>

     <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
     <footer class="footer">
      <div class="container">
        <p class="text-muted">A Project By Eng. Eniola Olusanjo from the Department of Electrical Electronics</p>
      </div>
    </footer>

     </div>

    
  <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.1.1.js"></script>
    <!-- <script>window.jQuery || document.write('<script src="js/vendor/jquery.min.js"><\/script>')</script> -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  
</body>
</html>
<!-- <?php
  if (isset($_POST['upload'])) {
    $docname = $_POST['docname'];
    $dpt = $_POST['dpt'];
    $file = $_FILES['file'];
      echo $docname.$dpt;

      print_r($file);
  }
?> -->