<?php
	session_start();
	include_once"includes/conn.php";
	include_once"functions/Error.php";
	include_once"functions/Success.php";


	if (isset($_POST['Register'])) {
		$dpt = $_POST['dpt'];
		$status = $_POST['status'];
		$fullname = mysqli_real_escape_string($conn,strip_tags($_POST['fullname']));
		$username = mysqli_real_escape_string($conn,strip_tags($_POST['username']));
		$password = mysqli_real_escape_string($conn,strip_tags($_POST['password']));

		$sqlc = "SELECT Username FROM users WHERE Username = '$username' ";
		$resc = mysqli_query($conn,$sqlc);
		if (mysqli_num_rows($resc)>0) {
			$_SESSION['er'] = 'unexist';
			unexist($conn);
			header('Location: Admin.php');
			exit();
		}

		if ($dpt == 'None' || $status == 'None') {
			$_SESSION['er'] = 'Nonedpts';
			header('Location: Admin.php');
		}elseif(!preg_match("/^[a-zA-Z ]*$/",$fullname)){
			$_SESSION['er'] = 'unchar';
			unchar($conn);
			header('Location: Admin.php');
		}elseif (empty($fullname) || empty($username) || empty($password)) {
			$_SESSION['er'] = 'EmptyField';
			EmptyField($conn);
			header('Location: Admin.php');
		}elseif (preg_match("/ /", $username)) {
			$_SESSION['er'] = 'spcun';
			Space($conn);
			header('Location: Admin.php');
		}else{
			$sql = "INSERT INTO users (Username, Password, Department, Fullname, Status) VALUES('$username','$password','$dpt','$fullname','$status')";
			$res = mysqli_query($conn,$sql);
			if ($res) {
				$_SESSION['suc'] = 'Added';
                Added($conn);
                header('Location: Admin.php');
			}
		}
	}

	if (isset($_POST['DeleteUser'])) {
		$username = $_POST['uname'];
		$dpt = $_POST['dpt'];

		if (empty($username) || $dpt == 'None') {
			$_SESSION['er'] = 'EmptyField';
			EmptyField($conn);
			header('Location: Admin.php');
		}else{
			$sql = "SELECT Username FROM users WHERE Username = '$username' ";
			$res = mysqli_query($conn,$sql);
			if (mysqli_num_rows($res)>0) {
				$sqlD = "DELETE FROM users WHERE Username = '$username' AND Department = '$dpt' ";
				$resD = mysqli_query($conn,$sqlD);
				if ($resD) {
					$_SESSION['suc'] = 'deleted';
					header('Location: Admin.php');
				}
			}else{
				$_SESSION['er'] = 'invd';
				header('Location: Admin.php');
			}
		}

		
			
	}

?>