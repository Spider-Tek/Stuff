<?php
  session_start();
  include_once"includes/conn.php";
  include_once"includes/UserDetails.php";
  include_once"functions/Success.php";
  include_once"functions/Error.php";
  if (!isset($_SESSION['id'])) {
    header('Location: index.php');
  }
  if ($status == 'Staff') {
    header('Location: index.php');
  }
  $id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="device-width initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/Admin.css">
  <link rel="stylesheet" type="text/css" href="font-awesome-4.6.3/css/font-awesome.css">
</head>
<body style="background:#F3F3F3">
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Archive</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 1px;">
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="Admin.php">Home</a></li>
            <li><a href=""> <div class="User">Welcome <?php echo $id ?> </div> </a></li>
             <li><a href="Logout.php"><i class="fa fa-sign-out"></i> Sign out</a></li>
             <!-- <a href="mailto:helpdesk@austincc.edu?subject=Email Assistance">Email Help Desk</a> --> 
          </ul>
        </div><!--/.nav-collapse -->
     
    </nav>  
    
      <div class="content">
      <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-8">
                     <h2>Administrator Panel</h2>   
                     <h4> Department <i class="fa fa-arrow-right"></i> <?php echo $dpt; ?> <i class="fa fa-arrow-right"></i> Status: <?php echo $status; ?></h4>
                    </div>
                    <div class="col-md-4">
                        <h4> Name: <?php echo $fullname; ?>  </h4> 
                    </div>
                </div>
                  

                </div>
                 <!-- /. ROW  -->
              
                <div class="row">
                  <div class="col-md-12">
                     
                     <div class="row">
                      <div class="col-md-9 search">
                        <form method="POST" action="">
                                  <select class="form-" name="dpt" value="">
                                    <option name="" value="None">------Select department------</option>
                                    <!-- <option name="" value="Computer Science">Computer Science</option> -->
                                    <option name="" value="Electrical Electronics">ELECTRICAL ELECTRONICS </option>
                                    <!-- <option name="" value="Physics">Physics</option> -->
                                  </select>
                                <input type="text" name="Docname" placeholder="Enter Document Name" />
                                <button name="search" <?php if ($status == 'Staff') { echo "disabled"; }?> class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                                <button name="viewAll" <?php if ($status == 'Staff') { echo "disabled"; }?> class="btn btn-primary"><i class="fa fa-eye"></i> View all</button> 
                                <button disabled="" name="Delete" <?php if ($status == 'Staff') { echo "disabled"; }?> class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button>
                        </form>
                      </div>
                      <div class="col-md-3">
                        <button <?php if ($status == 'Staff') { echo "disabled"; }?> data-toggle="modal" data-target="#myModal" class="btn btn-md btn-primary"><i class="fa fa-plus"></i> Add User</button>
                        <button <?php if ($status == 'Staff') { echo "disabled"; }?> data-toggle="modal" data-target="#myModalD" class="btn btn-md btn-danger"><i class="fa fa-trash"></i> Delete User</button>

                      </div>
                       
                     </div>
                        
                  </div>



                </div>
                 <hr />
            </div>
             <!-- /. PAGE INNER  -->
              <div class="alert alert-danger <?php
                if (isset($_SESSION['er'])) {
                    echo "sr-only1";
                  }else{
                    echo "sr-only";
                  }
                 ?>
               ?>" role="alert">
              <strong><?php
              if (isset($_SESSION['er']) && $_SESSION['er'] !== NULL) {
                if ($_SESSION['er'] == 'Nonedpt') {
                  Nonedpt($conn);
                  $_SESSION['er'] = NULL;
                }elseif($_SESSION['er'] == 'empDoc') {
                  EmptyDoc($conn);
                  $_SESSION['er'] = NULL;
                }elseif($_SESSION['er'] == 'Nonedpts') {
                  Nonedpts($conn);
                  $_SESSION['er'] = NULL;
                }elseif($_SESSION['er'] == 'unchar') {
                  unchar($conn);
                  $_SESSION['er'] = NULL;
                }elseif($_SESSION['er'] == 'EmptyField') {
                  EmptyField($conn);
                  $_SESSION['er'] = NULL;
                }elseif($_SESSION['er'] == 'spcun') {
                  Space($conn);
                  $_SESSION['er'] = NULL;
                }elseif($_SESSION['er'] == 'unexist') {
                  unexist($conn);
                  $_SESSION['er'] = NULL;
                }elseif($_SESSION['er'] == 'invd') {
                  NoUser($conn);
                  $_SESSION['er'] = NULL;
                }
              }
              ?></strong>
            </div>
                <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Document Table
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive scroll-table">
                                <table class="table table-striped table-bordered table-hover " id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Document Name </th>
                                            <th>Department</th>
                                            <th>Type</th>
                                            <th>Size</th>
                                            <th>Date Uploaded</th>
                                            <th><center> Action</center></th>
                                            <th><center> Delete</center></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                      
                                       include_once"DocumentTable.php";
                                      
                                   ?>
                                  
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                    
                      <button class="btn btn-primary"><i class="fa fa-pencil"></i> Send memo</button>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#myModalU" name="viewAll"><i class="fa fa-users"></i> View Users</button>
                    

            <div class="alert alert-success <?php
                if (isset($_SESSION['suc'])) {
                    echo "sr-only1";
                  }else{
                    echo "sr-only";
                  }
                 ?>
               ?>" role="alert">
              <strong><?php
              if (isset($_SESSION['suc']) && $_SESSION['suc'] !== NULL) {
                if ($_SESSION['suc'] == 'deleted') {
                  deleted($conn);
                  $_SESSION['suc'] = NULL;
                }elseif($_SESSION['suc'] == 'Added') {
                  Added($conn);
                  $_SESSION['suc'] = NULL;
                }
              }
              ?></strong>
            </div>
            </div>





            </div>

            <?php include_once"includes/AdminModal.php"; ?>
      
     <footer class="sticky-footer footer" style="margin-top:7.3%">
      <div class="container">
        <p class="text-muted">A Project By Eng. Eniola Olusanjo from the Department of Electrical Electronics</p>
      </div>
    </footer>

     </div>

    
  <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.1.1.js"></script>
    <!-- <script>window.jQuery || document.write('<script src="js/vendor/jquery.min.js"><\/script>')</script> -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  
</body>
</html>