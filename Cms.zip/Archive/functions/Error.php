<?php

	
	function EmptyField($conn){
		echo "<center>Please fill all fields</center>";
	}

	function invalidAcc($conn){
		echo "Invalid Account try again";
	}

	function Nonedpt($conn){
		echo "<center>Please Choose the department that has the document you want to delete</center>";
	}

	function Nonedpts($conn){
		echo "<center>Please Choose department / status</center>";
	}

	function EmptyDoc($conn){
		echo "<center>Please Enter the name of the document you want to delete</center>";
	}

	function unchar($conn){
		echo "<center>Only letters and whitespace is allowed for name</center>";
	}

	function Space($conn){
		echo "<center>Username must not contain space</center>";
	}

	function unexist($conn){
		echo "<center>Username already exist please try again</center>";
	}

	function NoUser($conn){
		echo "<center>No such user in database try again</center>";
	}


?>