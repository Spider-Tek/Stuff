<?php

	function FileName($conn){
		echo "<center>Please Enter document name</center>";
	}

	function Nonedpt($conn){
		echo "<center>Please Choose your department</center>";
	}

	function File2Large($conn){
		echo "<center>File too large(size must not be more than 500kb)</center>";
	}

	function ErrorUp($conn){
		echo "<center>Error uploading document try again</center>";
		
	}

	function Extension($conn){
		echo "<center>You cannot upload this kind of document(pdf only)</center>";
	}

	function NameExist($conn){
		echo "<center> Filename already exist please choose another name</center>";
	}

?>