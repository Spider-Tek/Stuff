<!-- THIS MODAL IS FOR ADDING USER -->
       <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel"><i class="fa fa-plus"></i> Add User</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="AddUser.php">

                                              <div class="row">
                                                <div class="col-md-12 ">
                                                  <div class="add"><select name="dpt" value="">
                                                        <option name="" value="None">Department</option>
                                                        <!-- <option name="" value="">Geology</option> -->
                                                        <option name="" value="Electrical Electronics"> ELECTRICAL ELECTRONICS</option>
                                                        <!-- <option name="" value="">Physics</option> -->
                                                      </select>
                                                
                                                 <select name="status" value="">
                                                        <option name="" value="None">Status</option>
                                                        <option name="" value="Super Admin">SuperAdmin</option>
                                                        <option name="" value="Admin">Admin</option>
                                                        <option name="" value="Staff">Staff</option>
                                                      </select>
                                                  </div>
                                                </div> 
                                                  
                                              </div>
                                               
                                              <div class="add"><input type="text" name="fullname" placeholder="Full Name" /></div>
                                              <div class="add"><input type="text" name="username" placeholder="Username" /></div>
                                              <div class="add"><input type="password" name="password" placeholder="Password" /></div>
                                              <div class="add"><button class="btn btn-primary btn-block" name="Register"> Register </button></div>
                                            </form>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
 
<!-- END OF MODAL FOR ADDING FRIEND -->      


<!-- THIS MODAL IS FOR DELETING USER -->
 <div class="modal fade" id="myModalD" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel"><i class="fa fa-trash"></i> Delete User</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form method="POST" action="AddUser.php">

                                              <div class="row">
                                                <div class="col-md-12 ">
                                                  <div class="add"><select name="dpt" value="">
                                                        <option name="" value="None">Department</option>
                                                        <!-- <option name="" value="">Geology</option> -->
                                                        <option name="" value="Electrical Electronics">Electrial Electronics</option>
                                                        <!-- <option name="" value="">Physics</option> -->
                                                      </select>
                                                
                                                 <select disabled="" name="" value="">
                                                        <option name="" value="">Status</option>
                                                        <option name="" value="">SuperAdmin</option>
                                                        <option name="" value="">Admin</option>
                                                        <option name="" value="">Staff</option>
                                                      </select>
                                                  </div>
                                                </div> 
                                                  
                                              </div>
                                               
                                              
                                              <div class="add"><input type="text" name="uname" placeholder="Username" /></div>
                                              <div class="add"><input type="text" name="" placeholder="Password" disabled /></div>
                                              <div class="add"><button name="DeleteUser" class="btn btn-danger btn-block"> Remove User </button></div>
                                            </form>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<!-- END OF MODAL FOR DELETING USER -->

<!-- THIS MODAL IS FOR USERS -->
 <div class="modal fade" id="myModalU" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel"><i class="fa fa-table"></i> Available Users</h4>
                                        </div>
                                        <div class="modal-body">
                                          <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Users Table
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive scroll-table">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Department</th>
                                            <th>Fullname</th>
                                            <th>Username</th>
                                            <th>Password</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php include_once"includes/UserTable.php" ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<!-- END OF MODAL FOR USERS -->