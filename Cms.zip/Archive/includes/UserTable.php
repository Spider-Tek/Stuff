<?php
	include_once"includes/conn.php";
	$sql = "SELECT * FROM users";
        $res = mysqli_query($conn,$sql);
        if (mysqli_num_rows($res)>0) {
              while ($rows = mysqli_fetch_assoc($res)) {
                      $dpt = $rows['Department'];
                      $fullname = $rows['Fullname'];
                      $username = $rows['Username'];
                      $password = $rows['Password'];
    	              $status = $rows['Status'];

    	   echo"
              <tr class='odd gradeX'>
              <td>$dpt</td>
  	          <td>$fullname</td>
    	      <td>$username</td>
              <td class='center'>$password</td>
              <td class='center'>$status</td>
        	  </tr>
             ";
         }
    }
         

?>