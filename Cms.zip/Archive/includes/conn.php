<?php
	$Host = "localhost";
	$Root = "root";
	$Password = "";
	$Database = "archive";
 	$conn = mysqli_connect($Host, $Root, $Password, $Database);
 	if (!$conn) {
 		die("Could not connect to Database").mysqli_connect_error();
 		exit();
 	}else{

 	}
?>